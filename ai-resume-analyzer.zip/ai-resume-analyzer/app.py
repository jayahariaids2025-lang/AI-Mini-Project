"""Gradio web app for the AI Resume Analyzer.  Run:  python app.py"""
import gradio as gr

from resume_analyzer import analyze
from resume_analyzer.ai_suggestions import get_suggestions


def run(resume: str, job_description: str, use_ai: bool):
    try:
        result = analyze(resume, job_description)
    except ValueError as exc:
        return str(exc), ""
    advice = get_suggestions(resume, job_description, result) if use_ai else "AI suggestions turned off."
    return result.summary(), advice


def load_sample(path: str) -> str:
    with open(path, encoding="utf-8") as f:
        return f.read().strip()


with gr.Blocks(title="AI Resume Analyzer") as demo:
    gr.Markdown("# AI Resume Analyzer\nPaste a resume and a job description to get a match score, skill gaps and AI suggestions.")
    with gr.Row():
        resume_box = gr.Textbox(lines=14, label="Resume text", value=load_sample("data/sample_resume.txt"))
        jd_box = gr.Textbox(lines=14, label="Job description", value=load_sample("data/sample_job_description.txt"))
    use_ai = gr.Checkbox(value=True, label="Use Gemini for suggestions (needs GEMINI_API_KEY)")
    button = gr.Button("Analyze", variant="primary")
    with gr.Row():
        analysis_out = gr.Textbox(label="Match analysis", lines=10)
        advice_out = gr.Textbox(label="AI suggestions", lines=10)
    button.click(run, [resume_box, jd_box, use_ai], [analysis_out, advice_out])

if __name__ == "__main__":
    demo.launch()
