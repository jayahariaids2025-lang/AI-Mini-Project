import pytest

from resume_analyzer import analyze, find_skills


def test_find_skills_uses_aliases_and_word_boundaries():
    skills = find_skills("Built models with sklearn and Power BI dashboards. Javascript too.")
    assert {"scikit-learn", "power bi", "javascript"} <= skills
    assert "java" not in skills  # 'java' must not match inside 'javascript'


def test_matched_and_missing_skills():
    result = analyze("I know Python and SQL.", "Need Python, SQL and Docker.")
    assert result.matched == ["python", "sql"]
    assert result.missing == ["docker"]
    assert result.coverage == pytest.approx(66.7, abs=0.1)


def test_identical_texts_score_high():
    text = "Python SQL pandas machine learning scikit-learn teamwork"
    result = analyze(text, text)
    assert result.score >= 95
    assert result.missing == []


def test_unrelated_texts_score_low():
    result = analyze("Experienced chef who loves baking bread.", "Python SQL machine learning engineer.")
    assert result.score < 15


def test_empty_input_raises():
    with pytest.raises(ValueError):
        analyze("", "Python developer")
