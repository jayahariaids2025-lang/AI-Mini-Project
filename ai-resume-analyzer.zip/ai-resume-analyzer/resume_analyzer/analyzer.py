"""Core scoring logic: TF-IDF similarity + skill coverage."""
import re
from dataclasses import dataclass, field

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from .skills import find_skills

COVERAGE_WEIGHT = 0.6
SIMILARITY_WEIGHT = 0.4


@dataclass
class AnalysisResult:
    score: float                 # overall 0-100
    similarity: float            # TF-IDF cosine similarity, 0-100
    coverage: float              # % of job skills found in resume, 0-100
    matched: list = field(default_factory=list)
    missing: list = field(default_factory=list)

    def summary(self) -> str:
        return (
            f"Overall match score: {self.score} / 100\n"
            f"Text similarity: {self.similarity}%\n"
            f"Skill coverage: {self.coverage}%\n\n"
            f"Matched skills: {', '.join(self.matched) or '-'}\n"
            f"Missing skills: {', '.join(self.missing) or '-'}"
        )


def clean(text: str) -> str:
    text = text.lower()
    text = re.sub(r"[^a-z0-9+#\s-]", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def _similarity(resume: str, jd: str) -> float:
    try:
        vec = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
        tfidf = vec.fit_transform([clean(resume), clean(jd)])
        return float(cosine_similarity(tfidf[0], tfidf[1])[0][0])
    except ValueError:  # empty vocabulary (e.g. only stop words)
        return 0.0


def analyze(resume: str, job_description: str) -> AnalysisResult:
    """Compare a resume with a job description."""
    if not resume.strip() or not job_description.strip():
        raise ValueError("Both resume and job description must be non-empty.")

    similarity = _similarity(resume, job_description)
    resume_skills = find_skills(resume)
    jd_skills = find_skills(job_description)

    matched = sorted(resume_skills & jd_skills)
    missing = sorted(jd_skills - resume_skills)
    coverage = len(matched) / len(jd_skills) if jd_skills else 0.0

    score = (COVERAGE_WEIGHT * coverage + SIMILARITY_WEIGHT * similarity) * 100
    return AnalysisResult(
        score=round(score, 1),
        similarity=round(similarity * 100, 1),
        coverage=round(coverage * 100, 1),
        matched=matched,
        missing=missing,
    )
