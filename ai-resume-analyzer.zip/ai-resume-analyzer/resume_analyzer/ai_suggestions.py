"""Optional Gemini-powered improvement suggestions."""
import os

from .analyzer import AnalysisResult

try:  # load a local .env file if python-dotenv is installed
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

DEFAULT_MODEL = "gemini-flash-latest"  # alias for the latest Flash model


def _build_prompt(resume: str, job_description: str, result: AnalysisResult) -> str:
    return f"""You are a career coach helping a student improve a resume for a specific job.

JOB DESCRIPTION:
{job_description}

RESUME:
{resume}

Analysis: match score {result.score}/100. Missing skills: {', '.join(result.missing) or 'none'}.

Give:
1. A 2-line summary of how well the resume fits.
2. Three specific improvements (be concrete).
3. Two rewritten resume bullet points that honestly highlight relevant experience.
Do not invent experience the candidate does not have. Keep it under 200 words."""


def get_suggestions(resume: str, job_description: str, result: AnalysisResult) -> str:
    """Return AI suggestions, or a helpful message if Gemini is unavailable."""
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        return ("AI suggestions are off: set GEMINI_API_KEY (see README) "
                "to enable Gemini-powered feedback.")
    try:
        from google import genai
        client = genai.Client(api_key=api_key)
        model = os.getenv("GEMINI_MODEL", DEFAULT_MODEL)
        response = client.models.generate_content(
            model=model, contents=_build_prompt(resume, job_description, result))
        return response.text
    except Exception as exc:  # network, quota, bad key, ...
        return f"AI request failed: {exc}"
