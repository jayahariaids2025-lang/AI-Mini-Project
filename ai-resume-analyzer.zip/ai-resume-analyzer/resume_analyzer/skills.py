"""Skill dictionary and skill extraction.

Each canonical skill maps to a list of aliases that count as a match.
Extend this dictionary to support more skills.
"""
import re

SKILLS = {
    # Languages
    "python": ["python"],
    "sql": ["sql", "mysql", "postgresql", "sqlite"],
    "java": ["java"],
    "c++": ["c++"],
    "javascript": ["javascript", "js"],
    # Data & ML libraries
    "pandas": ["pandas"],
    "numpy": ["numpy"],
    "matplotlib": ["matplotlib"],
    "seaborn": ["seaborn"],
    "scikit-learn": ["scikit-learn", "sklearn", "scikit learn"],
    "tensorflow": ["tensorflow"],
    "pytorch": ["pytorch"],
    # Concepts
    "machine learning": ["machine learning", "ml"],
    "deep learning": ["deep learning"],
    "nlp": ["nlp", "natural language processing"],
    "statistics": ["statistics", "statistical"],
    "data analysis": ["data analysis", "data analytics", "data-driven"],
    "data cleaning": ["data cleaning", "data cleansing", "data preprocessing"],
    "data visualization": ["data visualization", "data visualisation", "visualization", "visualisation"],
    "regression": ["regression"],
    "classification": ["classification"],
    # Tools
    "tableau": ["tableau"],
    "power bi": ["power bi", "powerbi"],
    "excel": ["excel"],
    "git": ["git", "github"],
    "docker": ["docker"],
    "flask": ["flask"],
    "streamlit": ["streamlit"],
    # Cloud
    "cloud": ["cloud"],
    "aws": ["aws", "amazon web services"],
    "azure": ["azure"],
    # Soft skills
    "communication": ["communication"],
    "teamwork": ["teamwork", "team player", "work in a team", "collaboration", "collaborative"],
    "problem solving": ["problem solving", "problem-solving"],
}


def _contains(text: str, phrase: str) -> bool:
    pattern = r"(?<![a-z0-9+#])" + re.escape(phrase) + r"(?![a-z0-9+#])"
    return re.search(pattern, text) is not None


def find_skills(text: str) -> set:
    """Return the set of canonical skills mentioned in `text`."""
    lowered = text.lower()
    return {
        skill
        for skill, aliases in SKILLS.items()
        if any(_contains(lowered, alias) for alias in aliases)
    }
